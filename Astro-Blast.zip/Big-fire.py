import pygame
import random
import math
import os

# Initialize pygame and mixer
pygame.init()
pygame.mixer.init()

# -------------------- Full Screen Window --------------------
infoObject = pygame.display.Info()
screen_width = infoObject.current_w
screen_height = infoObject.current_h
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Space Collector: Meteor Madness")

# -------------------- Colors and Fonts --------------------
BLACK   = (0, 0, 0)
WHITE   = (255, 255, 255)
RED     = (255, 0, 0)
YELLOW  = (255, 255, 0)
GRAY    = (128, 128, 128)
BLUE    = (0, 0, 255)   # For blue bonus fuel

clock = pygame.time.Clock()
base_font = pygame.font.SysFont("Arial", 25)
corner_font = pygame.font.SysFont("Arial", 38, bold=True)
gameover_font = pygame.font.SysFont("Arial", 100, bold=True)

# -------------------- Load Sound Files --------------------
try:
    shoot_sound = pygame.mixer.Sound("Laser_Shoot17.wav")
except Exception as e:
    print("Error loading Laser_Shoot17.wav:", e)
    shoot_sound = None

try:
    boom_sound = pygame.mixer.Sound("Explosion17.wav")
except Exception as e:
    print("Error loading Explosion17.wav:", e)
    boom_sound = None

try:
    tick_sound = pygame.mixer.Sound("tick.wav")
except Exception as e:
    print("Error loading tick.wav:", e)
    tick_sound = None

# -------------------- High Score Functions --------------------
def load_high_score():
    if os.path.exists("highscore.txt"):
        try:
            with open("highscore.txt", "r") as f:
                return int(f.read())
        except:
            return 0
    return 0

def save_high_score(score):
    with open("highscore.txt", "w") as f:
        f.write(str(score))

high_score = load_high_score()

# -------------------- Global Variables for Speed Increase and Bonus --------------------
exploded_count = 0      # Number of asteroids exploded
next_threshold = 5      # Every 5 explosions, new asteroids use increased speed
speed_multiplier = 1.0  # Multiplier for NEW asteroids

blue_bonus = None       # Stores the blue bonus fuel piece if present
double_fire_end = 0     # Time until which bonus fire is active (ms)
bonus_fire_duration = 10000  # 10 seconds duration
fire_bonus_count = 0    # Determines whether bonus fire is double (2) or triple (3)

# For tracking explosion events over the last 10 seconds
explosion_times = []    # List of timestamps (ms) of explosions

# We'll add a variable to control when to check for bonus appearance
last_bonus_check_time = 0  # We'll check for bonus only every 10 seconds

# -------------------- Game Object Settings --------------------
ship_size = 60
ship_speed = 10
ship_x = screen_width // 2
ship_y = screen_height // 2

bullet_speed = 20
bullet_radius = 10

fuel_radius = 20

score = 0
time_left = 30000  # Starting time: 30 seconds (30000 ms)
game_over = False

asteroids = []
fuel_pods = []
bullets = []

asteroid_spawn_time = 1500  # ms
last_asteroid_spawn = pygame.time.get_ticks()

# -------------------- Drawing Functions --------------------
def draw_ship(x, y):
    """Draw the spaceship as a triangle."""
    point1 = (x, y - ship_size // 2)
    point2 = (x - ship_size // 2, y + ship_size // 2)
    point3 = (x + ship_size // 2, y + ship_size // 2)
    pygame.draw.polygon(screen, WHITE, [point1, point2, point3])

def draw_asteroid(asteroid):
    """Draw an asteroid as a circle."""
    pygame.draw.circle(screen, GRAY, (int(asteroid["x"]), int(asteroid["y"])), asteroid["radius"])

def draw_fuel(fuel):
    """Draw a yellow fuel pod."""
    pygame.draw.circle(screen, YELLOW, (int(fuel["x"]), int(fuel["y"])), fuel["radius"])

def draw_blue_bonus(bonus):
    """Draw the blue bonus fuel piece."""
    pygame.draw.circle(screen, BLUE, (int(bonus["x"]), int(bonus["y"])), bonus["radius"])

def draw_bullet(bullet):
    """Draw a bullet as a circle."""
    pygame.draw.circle(screen, RED, (int(bullet["x"]), int(bullet["y"])), bullet["radius"])

# -------------------- Spawning Functions --------------------
def spawn_asteroid():
    """Create a new asteroid using current speed_multiplier."""
    edge = random.choice(["top", "bottom", "left", "right"])
    size_type = random.choice(["small", "medium", "large"])
    if size_type == "small":
        radius = 30
        hp = 1
        speed = random.uniform(6, 10)
    elif size_type == "medium":
        radius = 40
        hp = 2
        speed = random.uniform(4, 8)
    else:
        radius = 50
        hp = 3
        speed = random.uniform(2, 6)
    speed *= speed_multiplier  # Apply multiplier for new asteroids
    if edge == "top":
        x = random.randint(0, screen_width)
        y = -radius
        angle = random.uniform(20, 160)
    elif edge == "bottom":
        x = random.randint(0, screen_width)
        y = screen_height + radius
        angle = random.uniform(200, 340)
    elif edge == "left":
        x = -radius
        y = random.randint(0, screen_height)
        angle = random.uniform(-60, 60)
    else:
        x = screen_width + radius
        y = random.randint(0, screen_height)
        angle = random.uniform(120, 240)
    angle_rad = math.radians(angle)
    vx = speed * math.cos(angle_rad)
    vy = speed * math.sin(angle_rad)
    asteroid = {"x": x, "y": y, "vx": vx, "vy": vy, "radius": radius, "hp": hp, "type": size_type}
    asteroids.append(asteroid)

def spawn_fuel():
    """Create a yellow fuel pod."""
    x = random.randint(fuel_radius, screen_width - fuel_radius)
    y = random.randint(fuel_radius, screen_height - fuel_radius)
    fuel = {"x": x, "y": y, "radius": fuel_radius}
    fuel_pods.append(fuel)

def spawn_blue_bonus(current_time):
    """Create a blue bonus fuel piece that lasts for 30 seconds."""
    global blue_bonus, fire_bonus_count
    x = random.randint(fuel_radius, screen_width - fuel_radius)
    y = random.randint(fuel_radius, screen_height - fuel_radius)
    blue_bonus = {"x": x, "y": y, "radius": fuel_radius, "spawn_time": current_time}
    # בדיקה: אם explosion_times מכילה 4 או יותר אירועים – triple fire, אחרת double fire
    if len(explosion_times) >= 4:
        fire_bonus_count = 3
    else:
        fire_bonus_count = 2

# -------------------- Collision Functions --------------------
def check_collision_rect_circle(rect, circle):
    rx, ry, rw, rh = rect
    cx, cy, radius = circle
    closest_x = max(rx, min(cx, rx + rw))
    closest_y = max(ry, min(cy, ry + rh))
    distance = math.sqrt((closest_x - cx)**2 + (closest_y - cy)**2)
    return distance < radius

def check_collision_circle_circle(c1, c2):
    dx = c1[0] - c2[0]
    dy = c1[1] - c2[1]
    distance = math.sqrt(dx*dx + dy*dy)
    return distance < (c1[2] + c2[2])

# -------------------- Main Game Loop --------------------
def game_loop():
    global ship_x, ship_y, score, time_left, game_over, high_score
    global last_asteroid_spawn, asteroids, fuel_pods, bullets
    global exploded_count, next_threshold, speed_multiplier, blue_bonus, double_fire_end, explosion_times, fire_bonus_count, last_bonus_check_time

    ship_x = screen_width // 2
    ship_y = screen_height // 2
    score = 0
    time_left = 30000
    game_over = False
    asteroids = []
    fuel_pods = []
    bullets = []
    last_asteroid_spawn = pygame.time.get_ticks()

    exploded_count = 0
    next_threshold = 5
    speed_multiplier = 1.0
    blue_bonus = None
    double_fire_end = 0
    explosion_times = []
    last_bonus_check_time = 0  # Initialize bonus check timer

    prev_seconds = time_left // 1000

    running = True
    while running:
        dt = clock.tick(60)
        time_left -= dt
        current_time = pygame.time.get_ticks()
        if time_left <= 0:
            game_over = True

        seconds_left = time_left // 1000
        if seconds_left <= 10 and seconds_left < prev_seconds:
            if tick_sound:
                tick_sound.play()
        prev_seconds = seconds_left

        # עדכון explosion_times – שמירה רק של 10 השניות האחרונות
        explosion_times = [t for t in explosion_times if current_time - t <= 10000]

        # בדיקה: אם עברו 10 שניות מאז הבדיקה האחרונה, נבדק מספר הפיצוצים של 10 השניות האחרונות.
        if current_time - last_bonus_check_time >= 10000:
            if len(explosion_times) >= 3 and blue_bonus is None:
                spawn_blue_bonus(current_time)
            last_bonus_check_time = current_time  # עדכון זמן הבדיקה
            # לא מאפסים את explosion_times כאן, כך שבמידה ולא נאסף Blue Bonus (או נאסף ולא נאסף מיד)
            # ניתן גם לאפס אם רוצים שלא לשמור אירועים ישנים – נניח ננקה:
            # explosion_times = []

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                game_over = True
            if event.type == pygame.MOUSEMOTION:
                dx, dy = event.rel
                ship_x += dx
                ship_y += dy
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    if current_time < double_fire_end:
                        # אם בונוס fire פעיל – בהתאם ל-fire_bonus_count
                        if fire_bonus_count >= 3:
                            angles_deg = [-5, 0, 5]
                        else:
                            angles_deg = [-5, 5]
                        for ang in angles_deg:
                            rad = math.radians(ang)
                            vx = bullet_speed * math.sin(rad)
                            vy = -bullet_speed * math.cos(rad)
                            bullet = {"x": ship_x, "y": ship_y - ship_size//2, "vx": vx, "vy": vy, "radius": bullet_radius}
                            bullets.append(bullet)
                        if shoot_sound:
                            shoot_sound.play()
                    else:
                        bullet = {"x": ship_x, "y": ship_y - ship_size//2, "vx": 0, "vy": -bullet_speed, "radius": bullet_radius}
                        bullets.append(bullet)
                        if shoot_sound:
                            shoot_sound.play()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            ship_x -= ship_speed
        if keys[pygame.K_RIGHT]:
            ship_x += ship_speed
        if keys[pygame.K_UP]:
            ship_y -= ship_speed
        if keys[pygame.K_DOWN]:
            ship_y += ship_speed

        if ship_x < ship_size // 2:
            ship_x = ship_size // 2
        elif ship_x > screen_width - ship_size // 2:
            ship_x = screen_width - ship_size // 2
        if ship_y < ship_size // 2:
            ship_y = ship_size // 2
        elif ship_y > screen_height - ship_size // 2:
            ship_y = screen_height - ship_size // 2

        if current_time - last_asteroid_spawn > asteroid_spawn_time:
            spawn_asteroid()
            last_asteroid_spawn = current_time

        # Update asteroid positions with bouncing (like billiard balls)
        for asteroid in asteroids:
            asteroid["x"] += asteroid["vx"]
            asteroid["y"] += asteroid["vy"]
            if asteroid["x"] - asteroid["radius"] < 0:
                asteroid["x"] = asteroid["radius"]
                asteroid["vx"] = -asteroid["vx"]
            elif asteroid["x"] + asteroid["radius"] > screen_width:
                asteroid["x"] = screen_width - asteroid["radius"]
                asteroid["vx"] = -asteroid["vx"]
            if asteroid["y"] - asteroid["radius"] < 0:
                asteroid["y"] = asteroid["radius"]
                asteroid["vy"] = -asteroid["vy"]
            elif asteroid["y"] + asteroid["radius"] > screen_height:
                asteroid["y"] = screen_height - asteroid["radius"]
                asteroid["vy"] = -asteroid["vy"]

        for bullet in bullets:
            bullet["x"] += bullet["vx"]
            bullet["y"] += bullet["vy"]
        bullets = [b for b in bullets if 0 <= b["x"] <= screen_width and 0 <= b["y"] <= screen_height]

        ship_circle = (ship_x, ship_y, ship_size // 2)
        for asteroid in asteroids:
            asteroid_circle = (asteroid["x"], asteroid["y"], asteroid["radius"])
            if check_collision_circle_circle(ship_circle, asteroid_circle):
                game_over = True

        ship_rect = (ship_x - ship_size // 2, ship_y - ship_size // 2, ship_size, ship_size)
        for fuel in fuel_pods[:]:
            fuel_circle = (fuel["x"], fuel["y"], fuel["radius"])
            if check_collision_rect_circle(ship_rect, fuel_circle):
                fuel_pods.remove(fuel)
                score += 10
                time_left += 2000

        if blue_bonus is not None:
            bonus_circle = (blue_bonus["x"], blue_bonus["y"], blue_bonus["radius"])
            if check_collision_rect_circle(ship_rect, bonus_circle):
                blue_bonus = None
                score += 10
                time_left += 2000
                double_fire_end = current_time + bonus_fire_duration
                # איפוס רשימת explosion_times, כדי שלא יופעל שוב בינתיים
                explosion_times = []

        for bullet in bullets[:]:
            bullet_circle = (bullet["x"], bullet["y"], bullet["radius"])
            for asteroid in asteroids[:]:
                asteroid_circle = (asteroid["x"], asteroid["y"], asteroid["radius"])
                if check_collision_circle_circle(bullet_circle, asteroid_circle):
                    if bullet in bullets:
                        bullets.remove(bullet)
                    asteroid["hp"] -= 1
                    if asteroid["hp"] <= 0:
                        if boom_sound:
                            boom_sound.play()
                        explosion_times.append(current_time)
                        fuel_count = 0
                        if asteroid["type"] == "small":
                            fuel_count = 1
                        elif asteroid["type"] == "medium":
                            fuel_count = 2
                        elif asteroid["type"] == "large":
                            fuel_count = 3
                        for i in range(fuel_count):
                            spawn_fuel()
                        asteroids.remove(asteroid)
                        score += 5
                        exploded_count += 1
                        if exploded_count >= next_threshold:
                            speed_multiplier *= 1.1
                            next_threshold += 5
                    break

        screen.fill(BLACK)
        draw_ship(ship_x, ship_y)
        for asteroid in asteroids:
            draw_asteroid(asteroid)
        for fuel in fuel_pods:
            draw_fuel(fuel)
        if blue_bonus is not None:
            draw_blue_bonus(blue_bonus)
        for bullet in bullets:
            draw_bullet(bullet)

        if seconds_left <= 10:
            if (pygame.time.get_ticks() // 300) % 2 == 0:
                text_color = RED
            else:
                text_color = None
        else:
            text_color = WHITE

        if text_color is not None:
            score_text_surface = corner_font.render("Score: " + str(score), True, text_color)
            time_text_surface = corner_font.render("Time: " + str(max(0, seconds_left)), True, text_color)
            high_score_text_surface = corner_font.render("High Score: " + str(high_score), True, text_color)
            screen.blit(score_text_surface, (10, 10))
            screen.blit(time_text_surface, (10, 60))
            screen.blit(high_score_text_surface, (10, 110))
        
        pygame.display.update()

        if game_over:
            if score > high_score:
                high_score = score
                save_high_score(high_score)
            while True:
                screen.fill(BLACK)
                over_text = gameover_font.render("Game Over! Final Score: " + str(score), True, RED)
                high_score_over_text = gameover_font.render("High Score: " + str(high_score), True, WHITE)
                restart_text = gameover_font.render("Press C to play again or Q to quit", True, WHITE)
                screen.blit(over_text, (screen_width//2 - over_text.get_width()//2, screen_height//3))
                screen.blit(high_score_over_text, (screen_width//2 - high_score_over_text.get_width()//2, screen_height//3 + 120))
                screen.blit(restart_text, (screen_width//2 - restart_text.get_width()//2, screen_height//2))
                pygame.display.update()

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                        break
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_q:
                            running = False
                            break
                        if event.key == pygame.K_c:
                            game_loop()
                if not running:
                    break
            break

    pygame.quit()

game_loop()
